(remarks about editing see end of file)
Attention: 2.99f and following versions are not compatible to previous versions anymore!!!!
2.90 is the first A3 version

What's new in 2.99u ?

* Fixed: Player marker on map didn't work anymore (one preinit leftover because preinit on clients is to early for public variables send from the server... screw you BIS, screw you)
* Fixed: Because of damage value changes for satchels and other charges it needed to much of them to destroy a main target radio tower
* Changed: Enabled unit tags for admin spectating

What's new in 2.99t ?
(mission.sqm updated, lots of scripts changed!)

* Changed: More aggressive cleanup routines
* Changed: Destroyed vehicle simulation gets disabled after a while (server and clients)
* Fixed: Chemlights were not added correctly from gear layout save
* Added: Chemlights can be attached to the left shoulder now (if the player has a chemlight magazine in his gear). Available through Dom menu (normally U key/Teamswitch key)
* Added: Chopper doors can be opened and closed
* Added: Server and client FPS display in the left bottom corner

What's new in 2.99s ?
(mission.sqm updated, lots of scripts changed!)

* Added: 64 new sidemissions (thanks to the wonderfull work of the GITS guys, I've taken a few of your sidemissions :p), now 106 side missions!

What's new in 2.99r ?
(mission.sqm updated, lots of scripts changed!)

* Fixed: Wrongly initialized island_center variable which caused a script error in fnc getranpointouterair
* Fixed: Missiles were not available again after respawn/layoutgear retrieve
* Fixed: Secondary muzzle magazines (like grenade launcher mag) were not loaded after respawn/layoutgear retrieve
* Changed: Disabled AI building search again (might result in better performance)
* Fixed: Clouds will now hopefully finally show up on clients (and JIP clients too)
* Changed: Disabled side mission 6 (hangar on island) because of the stupid "three different objects for a single hangar" problem of Alpha 3
* Changed: If there are no arty vehicles at base the "Call Artillery" action in the Dom custom action menu won't show up
* Fixed: If an artillery vehicle at base is missing (removed for example) the arifire script won't quit with an error anymore
* Changed: Moved air bonus spawn positions outside of hangars
* Changed: Moved initial player spawn position, respawn position at base, player ammobox and flag into the main airport building
* Fixed: Possible undefined variable error in revive (carryaction)
* Fixed: Better position checking in artillery dialog (not using the hidden arty object anymore because object positions are not always updated immediately on clients in MP)
* Changed: Replaced flag at base with altis whiteboard

What's new in 2.99q ?

* Changed: Random minefield at main targets disabled (can cause performance issues on a dedicated server)
* Changed: Removed mine cluster magazine types from artillery which, guess what, can cause performance issues on a dedicated server
* Changed: Avoid main targets being too close during random main target creation (at least a second pass added)
* Fixed: Choosing unlimited revives started spectating immediately
* Added: Land vehicles won for resolving a side mission and main target mission can now also be lifted with a lift chopper (including tanks because Altis is huge)
* Removed: O_GMG_01_A_F and O_HMG_01_A_F from static AI enemy units (creates invisible gunners because it is of type UAV)
* Added: Missing laser batteries to ammo boxes
* Fixed: Player does now respawn with correct weapon layout if he has a secondary weapon in the Dom backpack and saved the layout
         (full saved layout will only be available after respawning at a MHQ or at base not when a player gets revived to avoid cheating)
* Changed: Out of bounds checks now using the correct mapSize from world config and not d_island_marker anymore to avoid wrong calculations because of wrong marker mapping to the actual island coordinates
* Added: New NATO pistol (only available in version higher 111471)
* Changed: Fugly workaround to make params on clients (including headless client) working again (headless client not sure, still not able to test)

What's new in 2.99p ?

* Changed: Removed hangar in steal the chopper sidemission, both available hangars are too small for the Kajman helicopter
* Changed: Increased attachto height for lifted wrecks to 25 meters to prevent pilot damage caused by burning wrecks (I hope 25 is enough)
* Changed: Layout gear is now also saved in profile namespace (thus making it persistent). Only available in non ranked versions.
* Fixed: Undefined variable error in save layoutgear script
* Fixed: One script used a wrong parameter when calling moveai script in the AI version causing a script error
* Fixed: AI drivers of AA vehicles at base removed to prevent them from driving around on the island *sigh*
* Fixed: UAV sidemission bonus vehicles were not spawned with crew rendering them pretty much useless
* Fixed: Sidemission which uses cargo box (was broken because it uses a cargo box which can't be destroyed, PhysX ftw)
* Fixed: Dropped ammo box cargo (weapons/ammo/items) was not correctly added to a dropped box if the box was loaded into a vehicle before
* Changed: Higher rating for players (200000 something to avoid friendly AI shooting at players *sigh*)

What's new in 2.99o ?
(mission.sqm updated, lots of scripts/files changed, again!)

* Fixed: Typo in vehicle attached to lift chopper height check, broke it completely
* Fixed: Finally solved the wreck disappearing issue (I'm sure :p)
* Fixed: Removed drivers of artillery battery vehicles at base to prevent them from driving around (*sigh*)
* Changed: Better distance check (without height) for revive map respawn markers (possible fix for a respawn positon related problem)
* Added: Three side missions, 45 now
* Changed: Better color for blue action menu entries
* Fixed: Welcome message was cut off
* Fixed: UI sound resources

What's new in 2.99n ?
(mission.sqm updated, lots of scripts changed!)

* Changed: Gametype back to Coop to get rid of the stupid unknown gametype bla message
* Changed: Tajins helmetcam updated to latest version
* Added: Both Stomper versions to side mission bonus vehicles
* Added: Darter UAV to (deployed) MHQ menu (if the player disconnects from the UAV the UAV will be deleted)
* Added: Two AA armored vehicles as base protection
* Changed: Artillery now uses engine artillery system. Two Scorcher batteries at base will provide fire support (please note that artillery ETA can be much longer now :))
* Added: Additional checks to prevent vehicles from falling under the map (and never stop falling)
* Added: Release weapons were missing in ranked weapon cargo
* Added: Missing Titan launchers
* Fixed: Sidemission 47 (was using OA class name for tanks)
* Fixed: Sidemission arty (sm50)
* Fixed: Disappearing MHQ and wrecks (hopefully)
* Changed: Flag side missions do fail now if the player carrying the flag dies or leaves the server
* Changed: Some dubbing sounds are back (yet there is exactly not one town name in the Alpha 3 dubbing pbo files)
* Lots of other changes under the hood, mainly bug fixes and major cleanup

What's new in 2.99m ?

* New: Mission moved to Altis
* Changed: Added full release content
* Changed: More sidemissions (now 42)
* Added: Missing vehicles on base (rep, ammo, fuel, medic truck)
* Changed: Random positions are now checked with isFlatEmpty instead of nearestbla commands
* plus other bugfixes

What's new in 2.99l ?
(mission.sqm file is the same as in 2.99k, nothing changed)

* Fixed: One more undefined variable issue
* Changed: Light enemy attack choppers do also show up again at main targets (as long as jets aren't available)
* Changed: Added missing weapons to ranked mode

What's new in 2.99k ?

* Changed: Protection zone objects are now disabled by default. They suddenly make helicopters explode
* Changed: Helicopters are placed +0.1m higher when they spawn
* Fixed: A few more undefined variables
* Fixed: Slow parachute drop was caused by ThingX (PhysX) object. Now back to normal again.
* Fixed: Flags are not deleted anymore (locality issue)
* Added: Two capture the flag style sidemissions

What's new in 2.99j ?

* Added: More sidemissions (all together 20 sidemissions now, Stratis is simply too small)
* Fixed: Heli lift, added missing vehicles
* Changed: Updated to reflect Beta 0.74 changes (undefined variables, etc) and added more vehicles (armor, etc)
* Changed: Enabled para drop (vehicle and ammo) for squad leaders again (no artillery drop yet)
* Changed: Enabled HALO for players (from base, if enabled and inside choppers if above a specific height)
* Changed: All addAction scripts are now precompiled (new feature in TOH/A3, accepts code instead of script name)

What's new in 2.99f ?

* Changed: Moved all Dom functions to CfgFunctions which will compile the functions before any init runs (all functions are compiled with compileFinal in a Dom release)
* Changed: Some mission init stuff moved to x_init\fn_preinit.sqf
* Changed: Weather may work again at mission start (maybe)

What's new in 2.99e ?

PLEASE NOTE THAT 2.99e DOES NOT WORK WITH THE CURRENT STABLE VERSION 0.54 BECAUSE OF THE NEW COMPILEFINAL SCRIPTING COMMAND
YOU DO NEED TO THE A3 DEV VERSION

* Changed: Send players with a non valid UID back to the lobby
* Changed: All clientside functions are now compiled with compileFinal, means they can't be changed during mission runtime anymore.
* Changed: Started with moving object creation from clients to the server (create vehicle @MHQ for example). Might setting up Battleye easier once it is available.
* Fixed: Side mission 4 did not end (containers can't be destroyed). Replaced container with a cargo box
* Fixed: Units will have their grenades back and usable again after respawn, finally really fixed

What's new in 2.99d ?

* Changed: Better algorithm to find the AI respawn position at main targets. Should move the AI respawn more away from the player attack vector (better for smaller islands like Stratis)
* Fixed: Weapons Throw and Put are no longer removed when a player respawns. Should fix the "not able to throw handgrenade after respawn" problem (though I'm not able to reproduce it)
* Changed: Saving custom layout gear (box at base) will transfer the gear of the player to the server too. In case the player reconnects he will get the same weapons/items/magazines again (this includes ammo count)
* Fixed: Hopefully removed the weird sounds a player sometimes made after revive respawn, probably caused by fire (please BI get rid of the feedback system, it's crap)

What's new in 2.99c ?

* Attempt to fix backpack/weapon on back action menu showing up on vehicles (might be an A3 engine isse)
* Fixed: Loaded magazines of all muzzles are now stored for respawn gear and layout gear handling instead of just the magazine of the first loaded muzzle
* Fixed: Items in backpack got doubled after respawn
* Fixed: Loaded magazines of all muzzles are now stored for backpack/weapon on back feature
* Fixed: Unconscious players were also added to the player list when the player himself was unconscious and in spectating mode (hopefully fixed)
* Changed: If an A3 version >= 0.55 is found Dom makes use of the new fog (experimental)

What's new in 2.99b ?

* Fixed: Local markers use visible position of remote objects now instead of the normal global position (which might not be updated on a client yet)
* Fixed: Backpack/Weapon on back had broken magazine handling due to respawn gear changes

What's new in 2.99a ?

* Fixed: Revive player marker got stuck at base (including moaning sounds)

What's new in 2.99 ?

* Fixed: Some magazines of specific weapons were not added correctly or not at all after respawn (wrong class used)

What's new in 2.98 (needs at least A3 ver 0.54) ?

* Changed: Only one version now for A3 Stable. It supports both, normal server and server with headless client connected (once again, see additional HC readme)
* Fixed: If the headless client unit was killed then the mission did not succeed
* Fixed: Headless client unit was shown in admin dialog
* Fixed: Small script error in ai respawn groups deletion script
* Added: Fog. Default is disabled, can be enabled in the lobby (Parameter "With Fog")

What's new in 2.97 ?

* Fixed: Sidemissions did not work correctly (getbonus script looped forever)
* Fixed: Moaning sounds are no longer played when the player is unconscious. playSound3D results in weird sounds when a camera is running.
* Changed: Better cleanup of groundWeaponHolder objects around the player ammo box at base

What's new in 2.96 ?

* Bugfixes
* Changed: Disabled "Cannot load dubbing x sound" messages (only visible in RPT)
* Fixed: Simulation of helicopters and planes in AI vehicle spawn script was still A2/OA,
  should spawn enemy air vehicles correctly again
* Changed: Enabled ranked version again (experimental)
* Fixed: AI version player air taxi did crash immediately after spawn
* Fixed: Halo jump action removed from flags at main targets. Exchanged with an option to spawn a vehicle (ATV).
* Changed: Revive moaning sounds
* Changed: Visual "name over head" feature (default is name cursortarget, "name over head" has to be enabled
  via ingame dom settings) uses now Draw3D mission eventhandler instead of one resource control per player
* Fixed: Cleanup of main target respawn groups could cause a script error
* Fixed: Cleanup of main target respawn groups was executed on the server instead on a headless client (when connected)
* Fixed: Sometimes camps at main targets spawned to close together
* Changed: Added new A3 dev build prone stances to stanceindicator, optimized stance indicator (both A3 Alpha versions supported, Stable and DEV)
* Fixed: A backpack in a players backpack will now also be saved and readded again after respawn/layout safe
* Fixed: Player respawned with custom layout gear instead of what he had prior death (after revive type change
  from handleDamage revive to after death revive)
* Fixed: Fuel loss while lifting a vehicle with a lift chopper did not work correctly
* Changed: If a MHQ gets lifted by a lift chopper before a main target is cleared and it had fuel removed
  because of driving to close to the main target fuel is added again before lifting
* Changed: Better message when a player drives a MHQ too close to the main target and fuel gets removed
* Fixed: Revive black out and black in cuts
* Changed: Select respawn is now delayed if there is no other player nearby (a little punishment for lone wolfs,
  was available immediately before)
* Fixed: Only medics can revive did not work at all

2.96 A3 Alpha DEV version only changes:
* Changed: Replaced some helper objects with flag poles (though still no flags available, just the poles)
* Changed: There is no separate headless client version anymore. The mission can either run standalone on a normal
  A3 server or makes automatically use of a headless client, if connected.
  The headless client slot is blocked for players, even if no headless client is connected
  (blocked already in the server lobby).
  See HC readme for more information on how to run/setup a HC.


What's new in 2.95 ?

* Bugfixes
* Backpack feature (weapon on back) does now also store the ammo count of magazines and primary weapon items
* Changed/Fixed: Only pilots can fly parameter does now work. If enabled only players with a pilot uniform and pilot headgear are able to fly.
  In combination with GVAR(only_pilots_can_fly) in i_client only those units get a pilot uniform and pilot headgear
* Added: Experimental FPS saver, can be disabled in the lobby (parameter Experimental FPS saver)
* Changed: No more custom player handleDamage system anymore for revive. When a player gets killed revive starts after respawn
  (handleDamage in A3 is simply just a mess and not worth to fight against the many issues it causes).
  This triggers some weapon/mag respawn problems (the inventory system in A3 is also, well, a mess) but it works.
* Added version with HC (headless client) support. Attention, needs the current DEV version of the A3 Alpha (does not start with the A3 "Stable" Alpha),
  see additional HC readme for more information.

What's new in 2.90 ?

* Bugfixes

What's new in 2.90 ?

* First A3 version
* Changed: Name resources over player heads not default anymore (can still be enabled), player name pops up if you point at a player now
* Changed: Dropped ammoboxes (from MHQ or chopper) are no longer magically refilled when a player loads them and drops them again. Can be refilled at ammo load point at base (please note that this still refills magazines because there is no way currently to read out the ammo count of magazines, something people ask for for years)
* Changed: Bonus vehicles now spawn with NO ammo and just a little bit fuel
* Changed: Repaired wrecks do no longer spawn with ammo and have just a little bit of fuel

====================

What's new in 2.80 ?

* Added: Some experimental headless client stuff!!! Please note that the Dom code has changed internally quite a lot because of that and you have to be carefully if you want to implement your own modifications/changes
  2.80 is not compatible to previous versions anymore

What's new in 2.71 ?

* Fixed: Domination action menus (teamswitch key) now really fixed!

What's new in 2.70 ?

* Fixed: Typo prevented base kick script to work
* Fixed: Commanding Menu was eating up mouse wheel movement in dialogs (map zooming for example), corresponding commanding menu dialogs are now created when the commanding menu is gone
* Fixed: Some chopper kills were written to plane kills in the database
* Fixed: Dropped ammo box handling was counting used boxes wrong
* Removed: Old ammobox handling

What's new in 2.69 ?

* Fixed various bugs which weren't found when testing 2.68 (for example chopper lift)
  Please update @Arma2NET with the one found in this package

What's new in 2.68 ?

* Changed: DomDatabase does need @Arma2Net 2.0 now. Please use the @Arma2NET folder found in the DOM268 download. Simply copy the @Arma2NET folder to your server game folder and start your server with -mod=@Arma2NET
  Please make sure that the user who starts the arma2oaserver.exe has enough rights to write to the @Arma2NET folder. @Arma2NET needs .NET client profile 4.0 installed on the server, clients DO NOT NEED @Arma2NET
  
  The DomDatabase plugin for @Arma2NET creates a SQlite database in your %LocalAppData%\DomDatabase folder. Various stats are saved per player in this database.
  You can also place a simple text file inside your server Arma2 folder called dservername.txt and add your server name in there, it will be used in the mission.
  PLEASE NOTE THAT @Arma2NET is only available on Windows!!! So you can't run this on a Linux server!
  PLEASE ALSO NOTE THAT THIS IS OPTIONAL! THE MISSION DOES ALSO WORK WITHOUT IT!
	
* Added: ACR DLC units, vehicles and weapons to the DLC version, does need the ACR DLC (DLC lite) as soon as it is available!
* Added: If ACRE is activated move player into "dead" channel when he is unconscious

What's new in 2.67 ?

* Fixed: Problem with Squad Mgmt, owner command, like the local command, does not like groups as parameter

What's new in 2.66 ?

* Fixed: Revive did not work anymore
* Fixed: Squad Management was broken

What's new in 2.65 ?

* Fixed: Box marker from dropped ammo boxes (MHQ for example) did not appear anymore
* Fixed: Admin Dialog is now really only available for admins

What's new in 2.64 ?

* Fixed a problem that only logged in admins could open "Show Status"


What's new in 2.63 ?

* Chopper lift fixed (all types work again)

* Player stats upgrade
(Please remove %LocalAppData%\DomDatabase\Dom.db before using the new version
and copy the new DomDatabase Addin files to your @Arma2NET Addins folder!!!)

Extra Player Stats dialog added, available via "Show Status" when the Arma2NET DomDatabase pluggin is available
See What's new in 2.62 on how to add Dom Arma2NET support!

* Some more optimizations and internal fixes

###########################################################################

What's new in 2.62 ?

* ArmA 2 standalone support dropped!!!!!!! Sorry!
OA build 94444 or higher is needed to run Dom now!!!

* The Domination network event system now uses publicVariableServer and publicVariableClient plus other network optimizations

* Some action menu entries are now only available via teamswitch key (OA default is key "T"), for example "Show Status", "Place MGNest", etc).

* Player numbers for the OA only version increased to 40 like the CO version

* Other optimizations

* Optional player stats save (needs ArmA2NET by Scott_NZ, http://forums.bistudio.com/showthread.php?131325-Arma2NET)
Copy the @Arma2NET folder in the Dom download file into your server @Arma2NET folder, edit the Settings.yaml file with a text editor in the @Arma2NET folder and add the following to
PublicKeyTokens:    - 430dbdb37cbe02a2 # DomDatabase
Add @Arma2NET to your server mod line.
It creates a SQlite database in your %LocalAppData%\DomDatabase folder. Currently only # times played, score total and time played is saved.
You can also place a simple text file inside your server Arma2 folder called dservername.txt and add your server name in there.

PLEASE NOTE THAT @Arma2NET is only available on Windows!!! So you can't run this on a Linux server!

###########################################################################

What's new in 2.61 ?

* New server lobby paramaeter: "Sidemissions random:". Default "Yes", if set to "No" the sidemission array won't get shuffeled.
(Makes only sense to set it to "No" if you plan to edit x_missionsetup and change the order of the side missions yourself).


* Main target bonus vehicles can also be set by adding the following to a target location object (d_target_x in the editor) init line:

Normal version:
this setVariable ["d_bonusvec", "A10_US_EP1"];

TT version:
this setVariable ["d_bonusvec_w", "A10_US_EP1"];this setVariable ["d_bonusvec_e", "Su25_TK_EP1"];

In this case no random bonus vehicle is chosen for the target but the one(s) added by setVariable in the location variable space.


* The same works for sidemissions too. But instead of a setVariable you have to add the following to your sidemission sqf file or to one of the common mission files:
GVAR(current_sm_bonus_vec) = "M1A1_US_DES_EP1";
TT version:
GVAR(current_sm_bonus_vec) = ["M1A1_US_DES_EP1", "T72_TK_EP1"];

If defined in a sidemission file those are chosen instead of random sidemission vehicles.

###########################################################################

Some remarks regarding editing...

If you want to place new targets just add another location logic with var name d_target_x where x has to be the next number after the last logic already placed.
x starts with 0 and ends with number of logics - 1. Don't forget a number in between otherwise the algorithm which reads in the targets stops at that position.

The algorithm will search automatically for the next city.
If there is no city nearby or you want to place the logic somewhere else simply add the following into the init line of the logic:
this setVariable ["d_cityname", "Whatevernameyoulike"]
This hinders the algo to search for a nearby city and simply uses the location position and as target name the variable d_cityname.

Changing the radius of a target is also easy, simply use:
this setVariable ["d_cityradius", 400]
in the init line of the logic. Default value is 300.

Bonus vehicle positions uses the same concept. But instead of logics it uses markers and x starts with 1 and not with 0.
d_bonus_vec_positions_1 - d_bonus_vec_positions_x
d_bonus_air_positions_1 - d_bonus_air_positions_x
The direction of the markers is also the spawn direction for the bonus vehicles.

The direction of other markers also determines spawn direction for other objects:
d_pos_aihut
d_player_ammobox_pos
d_base_chopper_fac
d_base_wreck_fac
d_base_jet_fac
d_bonus_create_pos
(the ACE version has some position markers more for the various boxes)

d_base_marker determines the base. Dom will create the base triggers at the position and direction and size of this marker.

d_island_marker is needed as most of the islands are a way of concerning center positions. AI units which have waypoints outside the normal 0,0 - islandsizex, islandsizey won't move. So this marker helps to find the correct dimensions of the island.

d_isledefense_marker determines the area in which enemy patrols will be created and do their patrol job.

Alpha of all the non empty markers is set to 0 at mission start.


* Added possibility to reserve whatever slots you like for members, based on UIDs.
Check GVAR(uid_reserved_slots) = []; and GVAR(uids_for_reserved_slots) = []; in i_client.sqf

* Infantry groups are reduced now if no players are nearby (if enabled, default disabled). Only the leader stays and will do his duties.
The reduce distance can be adjusted in i_server.sqf, GVAR(reduce_distance)
